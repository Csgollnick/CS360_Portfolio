package com.effusivedesignandtech.eventually;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class UpdateEvent extends AppCompatActivity {

    private TextView updateName = (TextView) findViewById(R.id.updateName);
    private EditText updateTime = (EditText) findViewById(R.id.updateTime);
    private EditText updateDate = (EditText) findViewById(R.id.updateDate);
    private TextView updateDescription = (TextView) findViewById(R.id.updateDescription);
    private eventlist eventID = new eventlist();
    private EventsDB eventsdb =  new EventsDB(this);
    private Button updateBtn = (Button) findViewById(R.id.updateSubmit);


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_event);

        updateName.setText(eventsdb.updateName(eventID.id));
        updateDate.setText(eventsdb.updateDate(eventID.id));
        updateTime.setText(eventsdb.updateTime(eventID.id));
        updateDescription.setText(eventsdb.updateDescription(eventID.id));

        updateBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String udname = updateName.getText().toString();
                String udtime = updateTime.getText().toString();
                String uddate = updateDate.getText().toString();
                String uddesc = updateDescription.getText().toString();
                eventsdb.updateEvent(eventID.id,udname,uddate,udtime,uddesc);
                startActivity(new Intent(UpdateEvent.this, eventlist.class));
            }
        });



    }
}