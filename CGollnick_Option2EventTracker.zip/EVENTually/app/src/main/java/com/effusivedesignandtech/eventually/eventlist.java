package com.effusivedesignandtech.eventually;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.icu.text.SimpleDateFormat;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.Calendar;
import java.util.Date;
import java.time.*;
import java.util.Locale;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;


public class eventlist extends AppCompatActivity {
    EventsDB event1;
    private TextView time1;
    private TextView date1;
    private TextView name1;
    private TextView desc1;
    private Button update;
    private Button delete;
    private ImageButton next;
    private ImageButton previous;
    public long id;
    public String date;
    public String today;
    public SimpleDateFormat sdf;
    public String message;

    private static final int PERMISSION_RQST_SEND = 0;

    private FloatingActionButton newevent;
    private FloatingActionButton smsNot;
    private SmsNotification smsnotify = new SmsNotification();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_eventlist);

        time1 = (TextView) findViewById(R.id.time1);
        date1 = (TextView) findViewById(R.id.date1);
        name1 = (TextView) findViewById(R.id.name1);
        desc1 = (TextView) findViewById(R.id.description);
        update = (Button) findViewById(R.id.updateBtn);
        delete = (Button) findViewById(R.id.deleteButton);
        next = (ImageButton) findViewById(R.id.nextDate);
        previous = (ImageButton) findViewById(R.id.prevDate);

        newevent = (FloatingActionButton) findViewById(R.id.addEventFAB);
        smsNot = (FloatingActionButton) findViewById(R.id.smsFab);

        event1 = new EventsDB(this);

        SimpleDateFormat sdf = new SimpleDateFormat("MM.dd.yyyy");
        date = sdf.format(new Date());

        date1.setText(date);


        //Add Events via FAB
        newevent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(eventlist.this, NewEvent.class));
            }
        });

        //Register to Get Text Updates about events
        smsNot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(eventlist.this, SmsNotification.class));
            }
        });

        //Delete Events
        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                id = event1.getID(date);
                if (id > 0) {
                    event1.deleteEvent(id);
                    Toast.makeText(eventlist.this, "Event Deleted", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(eventlist.this, "no event exist", Toast.LENGTH_SHORT).show();
                }
            }
        });

        //update current Events for day
        date1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                name1.setText(event1.getName(date));
                time1.setText(event1.getTime(date));
                desc1.setText(event1.getDescription(date));
                id = event1.getID(date);
            }
        });

        //Update to net day
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                date1.setText(addOneDay(date));
                date = addOneDay(date);
            }
        });

        //Update to previous Day
        previous.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                date1.setText(removeOneDay(date));
                date = removeOneDay(date);
            }
        });

        //Update Current Event
        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(eventlist.this, UpdateEvent.class));
            }
        });


    }

    //Method to add 1 day to date
    public static String addOneDay(String date) {
        return LocalDate.parse(date).plusDays(1).toString();
    }

    //method to remove 1 day from date
    public static String removeOneDay(String date) {
        return LocalDate.parse(date).minusDays(1).toString();
    }

    protected void sendSMSMessage() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.SEND_SMS)) {
            } else {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, PERMISSION_RQST_SEND);
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case PERMISSION_RQST_SEND: {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    SmsManager smsManager = SmsManager.getDefault();
                    today = sdf.format(new Date());
                    String timenow = new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date());
                    if (event1.getID(today) != 0) {
                        message = "You Have an Event Today";
                    } else {
                        message = "No Events Today";
                    }
                    if (timenow == "01:00") {
                        smsManager.sendTextMessage(smsnotify.phone, null, message, null, null);
                    }
                    return;
                }
            }
        }


    }
}