package com.effusivedesignandtech.eventually;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {
    private EditText userName;
    private EditText password;
    private Button loginButton;
    private Button createButton;
    public UserDB dbUser;
    Boolean access;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        userName = (EditText) findViewById(R.id.username);
        password = (EditText) findViewById(R.id.password);
        loginButton = (Button) findViewById(R.id.Login);
        createButton = (Button) findViewById(R.id.create);
        loginButton.setEnabled(false);
        dbUser = new UserDB(this);

        //watch text field changes
        userName.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence u, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence u, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable u) {
                //null Check for nameText
                if (u.toString().equals("")) { // checks if null
                    loginButton.setEnabled(false);
                } else {
                    loginButton.setEnabled(true);
                }
            }
        });

        /*
         * Functionality for the login button
         * checks user and password against database
         * display appropriate messages based on entry against DB
         * */
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String un = userName.getText().toString();
                String pwd = password.getText().toString();

                if (un.equals("") || pwd.equals("")) {
                    Toast.makeText(MainActivity.this, "Enter all fields", Toast.LENGTH_SHORT).show();
                }

                access = dbUser.checkUserPassword(un, pwd);
                if (access == true) {
                    startActivity(new Intent(MainActivity.this, eventlist.class));
                } else {
                    Toast.makeText(MainActivity.this, "Invalid Credentials", Toast.LENGTH_SHORT).show();
                }
            }

        });

         //Functionality for creating a user account button

        createButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, CreateUser.class));
            }
        });
    }
}