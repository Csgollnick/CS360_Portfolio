package com.effusivedesignandtech.eventually;

/*
 *   Start Section for implementing users Database
 */

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.nfc.Tag;
import android.util.Log;


public class UserDB extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "users.db";
    public static final int VERSION = 1;


    public UserDB(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    public static final class UsersTable {
        public static final String TABLE_NAME = "users_table";
        public static final String COL_1 = "_id";
        public static final String COL_2 = "USERNAME";
        public static final String COL_3 = "PASSWORD";
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + UsersTable.TABLE_NAME + " (" +
                UsersTable.COL_1 + " INTEGER primary key autoincrement, " +
                UsersTable.COL_2 + " TEXT, " +
                UsersTable.COL_3 + " TEXT) " );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion,
                          int newVersion) {
        db.execSQL("drop table if exists " + UsersTable.TABLE_NAME);
        onCreate(db);
    }
    //Method to add to database, call this in classes
    public boolean insertData(String username, String password) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues contentValues = new ContentValues();
        contentValues.put(UsersTable.COL_2, username);
        contentValues.put(UsersTable.COL_3, password);

        long result = db.insert(UsersTable.TABLE_NAME,null,contentValues);
        if (result == -1) {
            return false;
        } else {
            return true;
        }
    }

    //Method to check for username existence
    public Boolean checkUser(String username) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursorUser = db.rawQuery("SELECT * FROM " + UsersTable.TABLE_NAME +  " WHERE username = ?", new String[] { username });
        if (cursorUser.getCount() > 0 ) {
            return true;
        } else {
            return false;
        }
    }


    //Method to check for username and password combinations for authentication

    public boolean checkUserPassword(String username, String password) {

        SQLiteDatabase db = getReadableDatabase();
        String sql = "Select * From " +  UsersTable.TABLE_NAME + " where username = ? and password = ?";
        Cursor cursorUP = db.rawQuery(sql, new String[] {username,password});
        if (cursorUP.getCount() > 0) {
            return true;
        } else {
            return false;
        }
    }

}