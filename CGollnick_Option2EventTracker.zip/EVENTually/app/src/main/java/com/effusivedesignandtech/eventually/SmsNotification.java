package com.effusivedesignandtech.eventually;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;

public class SmsNotification extends AppCompatActivity {

    private EditText mobileNum = (EditText) findViewById(R.id.editTextNumber);
    private Switch smsAllow = (Switch) findViewById(R.id.allowSmsSwitch);
    private Button submitSms = (Button) findViewById(R.id.submitsmsbutton);
    public String phone;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_notification);

        submitSms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                phone = mobileNum.toString();
                startActivity(new Intent(SmsNotification.this, eventlist.class));
            }
        });

    }

}