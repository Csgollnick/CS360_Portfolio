package com.effusivedesignandtech.eventually;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.icu.text.SimpleDateFormat;

import java.util.Date;

public class EventsDB extends SQLiteOpenHelper{
    public static final String DATABASE_NAME = "events.db";
    public static final int VERSION = 1;

    public EventsDB(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    //Decalre Table information
    public static final class EventsTable {
        public static final String TABLE_NAME = "events_table";
        public static final String COL_1 = "_id";
        public static final String COL_2 = "Name";
        public static final String COL_3 = "Date";
        public static final String COL_4 = "Time";
        public static final String COL_5 = "Description";
    }

    //Creates table and columens
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + EventsTable.TABLE_NAME + " (" +
                EventsTable.COL_1 + " INTEGER primary key autoincrement, " +
                EventsTable.COL_2 + " TEXT, " +
                EventsTable.COL_3 + " TEXT, " +
                EventsTable.COL_4 + " TEXT, " +
                EventsTable.COL_5 + " TEXT) " );
    }

    //Upgrade methods
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion,
                          int newVersion) {
        db.execSQL("drop table if exists " + EventsTable.TABLE_NAME);
        onCreate(db);
    }

    //Delete event by ID
    public boolean deleteEvent(Long id) {
        SQLiteDatabase db = getWritableDatabase();
        int rowsDeleted = db.delete(EventsTable.TABLE_NAME, EventsTable.COL_1 + " = ?",
                new String[] { Long.toString(id) });
        return rowsDeleted > 0;
    }

    //Method to add to database, call this in classes
    public boolean addEvent(String name, String date, String time, String description) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues contentValues = new ContentValues();
        contentValues.put(EventsTable.COL_2, name);
        contentValues.put(EventsTable.COL_3, date);
        contentValues.put(EventsTable.COL_4, time);
        contentValues.put(EventsTable.COL_5, description);

        long result = db.insert(EventsTable.TABLE_NAME,null,contentValues);
        if (result == -1) {
            return false;
        } else {
            return true;
        }
    }

    public boolean updateEvent(long id, String name, String date, String time, String desc) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(EventsTable.COL_2, name);
        values.put(EventsTable.COL_3, date);
        values.put(EventsTable.COL_4, time);
        values.put(EventsTable.COL_5, desc);

        int rowsUpdated = db.update(EventsTable.TABLE_NAME, values, "_id = ?",
                new String[] { Float.toString(id) });
        return rowsUpdated > 0;
    }

    /*
    * Series of methods to fill in
    * the data fields when viewing
    * a days events
    * */
    //get Event ID
    public long getID(String date) {
        long id = 0;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("Select * From " + EventsTable.TABLE_NAME + " Where date = ?", new String[] {date});
        if (cursor.moveToFirst()) {
            do {
                id = cursor.getLong(0);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return id;
    }
    //Get Event Date
    public String getDate(String date) {
        String eDate ="";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("Select * From " + EventsTable.TABLE_NAME + " Where date = ?", new String[] {date});
        if (cursor.moveToFirst()) {
            do {
                eDate = cursor.getString(2);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return eDate;
    }
    //Get Event Time
    public String getTime(String date) {
        String time ="";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("Select * From " + EventsTable.TABLE_NAME + " Where date = ?", new String[] {date});
        if (cursor.moveToFirst()) {
            do {
                time = cursor.getString(3);
            } while (cursor.moveToNext());
        }
        cursor.close();

        return time;
    }
    //Get event Name
    public String getName(String date) {
        String name ="";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("Select * From " + EventsTable.TABLE_NAME + " WHERE date = ?", new String[] {date});
        if (cursor.moveToFirst()) {
            do {
                name = cursor.getString(1);
            } while (cursor.moveToNext());
        }
        cursor.close();

        return name;
    }

    //Get Event Descriptions
    public String getDescription(String date) {
        String desc = "";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("Select * From " + EventsTable.TABLE_NAME + " Where date = ?", new String[] {date});
        if (cursor.moveToFirst()) {
            do {
                desc = cursor.getString(4);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return desc;
    }



    /*
    * Series of methods to get
    * the data for given fields to
    * update a given event based on ID
    *
    * */
    //Get Event Date
    public String updateDate(long id) {
        String uid = String.valueOf(id);
        String uDate ="";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("Select * From " + EventsTable.TABLE_NAME + " Where id = ?", new String[] {uid});
        if (cursor.moveToFirst()) {
            do {
                uDate = cursor.getString(2);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return uDate;
    }
    //Get Event Time
    public String updateTime(long id) {
        String uid = String.valueOf(id);
        String utime ="";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("Select * From " + EventsTable.TABLE_NAME + " Where id = ?", new String[] {uid});
        if (cursor.moveToFirst()) {
            do {
                utime = cursor.getString(3);
            } while (cursor.moveToNext());
        }
        cursor.close();

        return utime;
    }
    //Get event Name
    public String updateName(long id) {
        String uid = String.valueOf(id);
        String uname ="";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("Select * From " + EventsTable.TABLE_NAME + " WHERE id = ?", new String[] {uid});
        if (cursor.moveToFirst()) {
            do {
                uname = cursor.getString(1);
            } while (cursor.moveToNext());
        }
        cursor.close();

        return uname;
    }

    //Get Event Descriptions
    public String updateDescription(long id) {
        String uid = String.valueOf(id);
        String udesc = "";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("Select * From " + EventsTable.TABLE_NAME + " Where id = ?", new String[] {uid});
        if (cursor.moveToFirst()) {
            do {
                udesc = cursor.getString(4);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return udesc;
    }



}
