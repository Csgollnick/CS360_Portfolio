package com.effusivedesignandtech.eventually;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CreateUser extends AppCompatActivity {

    private EditText userName;
    private EditText password;
    private TextView userExists;
    private TextView pwReqs;
    private Button register;
    public UserDB dbUser;
    public int pwReqPass = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_user);

        userName = (EditText) findViewById(R.id.newUserName);
        password = (EditText) findViewById(R.id.newPassword);
        userExists= (TextView) findViewById(R.id.textUserCheck);
        pwReqs = (TextView) findViewById(R.id.passwordCheck);
        register = (Button) findViewById(R.id.submitNewUser);
        register.setEnabled(false);
        dbUser = new UserDB(this);

        userName.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence u, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence u, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable u) {
                //null Check for nameText
                if (u.toString().equals("")) { // checks if null
                    register.setEnabled(false);
                } else {
                    register.setEnabled(true);
                }
            }
        });

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    Boolean exist = dbUser.checkUser(userName.getText().toString());
                    if(exist == false) {
                        dbUser.insertData(userName.getText().toString(), password.getText().toString());
                        Toast.makeText(CreateUser.this, "Registration Successful", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(CreateUser.this, MainActivity.class));
                    } else {
                        Toast.makeText(CreateUser.this, "User Already Exists", Toast.LENGTH_SHORT).show();

                    }



            }
        });
    }
    //public void addUser() {


        //}
    /*public boolean pwCheck() {

        Pattern smLetter = Pattern.compile("[a-z]");
        Pattern capLetter = Pattern.compile("[A-Z]");
        Pattern digit = Pattern.compile("[0-9]");
        Pattern special = Pattern.compile("[{!@#$%^&*()_+=|<>?{}~}]");

        String pw = password.getText().toString();
        if (pw.length() >= 8) {
            Matcher hasLetter1 = smLetter.matcher(pw);
            Matcher hasLetter2 = capLetter.matcher(pw);
            Matcher hasDigit = digit.matcher(pw);
            Matcher hasSpecial = special.matcher(pw);

            return hasLetter1.find() && hasLetter2.find() && hasDigit.find() && hasSpecial.find();
            pwReqPass = 1;


        }

        else {
            pwReqs.setText("Password Must Contain at least: (1) Number, (1) Uppercase Letter, (1) Lowercase Letter, (1) Special Character, and (8) Characters minimmum");
            pwReqPass = 0;
            return ;
            }


    };*/
    }


