package com.effusivedesignandtech.eventually;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TimePicker;

public class NewEvent extends AppCompatActivity {
    private EditText eventName;
    private EditText eventDescriptor;
    private Button addEventBtn;
    private EditText eventTime;
    private EditText eventDate;
    EventsDB event;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_event);

        eventName = (EditText) findViewById(R.id.eventName);
        eventDate = (EditText) findViewById(R.id.eventDate);
        eventTime = (EditText) findViewById(R.id.eventTime);
        eventDescriptor = (EditText) findViewById(R.id.eventDescription);
        addEventBtn = (Button) findViewById(R.id.addEventBtn);
        event = new EventsDB(this);


        addEventBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = eventName.getText().toString();
                String time = eventTime.getText().toString();
                String date = eventDate.getText().toString();
                String desc = eventDescriptor.getText().toString();
                event.addEvent(name,date,time,desc);
                startActivity(new Intent(NewEvent.this, eventlist.class));
            }
        });
    }
}